import sqlite3 as sql


class User():

    db_register = sql.connect('server.db')
    cursor = db_register.cursor()

    '''cursor.execute(CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    login VARCHAR(20),
    password VARCHAR(20)))
    db_register.commit()

    def ent(in_login):
        if in_login == '1' : print('helo')

    cursor.execute("""INSERT INTO workers (Имя, Фамилия, Отчество, Логин, Пароль, Должность, Дата, 
                    Номер)""")

    db_register.commit()

    #cursor.execute("""DELETE FROM users """)

    db_register.commit()'''

    '''cursor.execute("""INSERT INTO workers (ID, Имя, Фамилия, Отчество, Логин, Пароль, Должность, Дата, 
                        Номер) VALUES('3','4', '4', '4', '4', '4', 'Guide', '01.01.2000', '2')""")'''

    #cursor.execute('Drop table products')
    cursor.execute('''CREATE TABLE products (ID INTEGER PRIMARY KEY NOT NULL, 
 Название varchar(50),
 Категория varchar(20),
 Бренд varchar(20),
 Характеристики TEXT,
 Опиcание TEXT,
 Количество int(11),
 Цена DECIMAL(8,2),
 Тип varchar(10));''')

    cursor.execute("""INSERT INTO workers (Имя, Фамилия, Отчество, Логин, Пароль, Должность, Дата, 
                       Номер) VALUES ('Xleb', 'xleb', 'Xleb', 'xleb', 'xleb', 'Administrator', '2023.12.10')""")

    # Сохранение изменений
    db_register.commit()
    for i in cursor.execute('''SELECT * FROM workers'''):
        print(i)

