import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QMessageBox
from dis_ui_main import Ui_MainWindow
from dis_Register import Ui_Form
from dis_wid_analyze import Ui_Dialog_analyze
from dis_wid_add_products import Ui_Dialog_products
from dis_wid_add_employees import Ui_Dialog_employee
from dis_wid_add_order import Ui_Form_order
from dis_wid_kol_vo import Ui_Dialog_kol_vo

from database import Database
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QMessageBox, QDialog, QComboBox
from PyQt6.QtSql import QSqlQueryModel
from PyQt6.QtCore import QDateTime, Qt
import json
from docx import Document
#background-color: qlineargradient(spread:pad, x1:0, y1:0.131, x2:1, y2:0,
# stop:0 rgba(83, 52, 94, 255), stop:1 rgba(92, 203, 186, 255));

class LoginForm(QWidget, Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.datab = Database()
        self.but_login.clicked.connect(self.entry)

    def entry(self):
        self.openMainWindow(self.r_comboBox_position.currentText())
        self.close()

        '''try:
            data = self.datab.query_entry(self.r_le_login.text(), self.r_le_password.text(), self.r_comboBox_position.currentText())
            print(data, self.r_le_login.text(), self.r_le_password.text())
            if not data:
                QMessageBox.critical(self, 'Ошибка', 'Неправильные данные!')
            else:
                self.openMainWindow( self.r_comboBox_position.currentText())
                self.close()  # Закрываем окно логина после успешного входа
        except Exception as e:
            QMessageBox.critical(self, 'Ошибка', f'Произошла ошибка: {str(e)}')'''

    def openMainWindow(self, position):
        self.mainWindow = MainWindow()
        self.mainWindow.show()
        if position == 'Employee':
            self.mainWindow.but_employees.setVisible(False)
        self.close()

class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.datab = Database()
        self.widget_add_ord = widget_add_order()
        self.widget_kol = QDialog()
        self.widget_add = QDialog()
        self.table_name = 'workers'
        self.data_input = []
        self.param = []
        self.order = {}
        self.sum = None

        self.but_products.clicked.connect(lambda checked, table_name='products': self.opr_table(table_name))
        self.but_employees.clicked.connect(lambda checked, table_name='workers': self.opr_table(table_name))
        self.but_delete.clicked.connect(lambda: self.delete_column(self.table_name))
        self.but_analyze.clicked.connect(self.openWingetAnalyze)
        self.but_add.clicked.connect(lambda: self.openWingetAdd(self.table_name))
        self.but_order.clicked.connect(self.openWingetAddOrder)
        self.but_search.clicked.connect(self.search_column)
        self.action_about.triggered.connect(self.show_about_info)
        self.action_exit.triggered.connect(self.close_all_windows)
        self.tableView.clicked.connect(self.opr_products)

        self.widget_add_ord.but_cancel_order.clicked.connect(self.cancel_order)
        self.widget_add_ord.but_export_order.clicked.connect(self.print_structure_order_in_word)
        self.widget_add_ord.but_save_order.clicked.connect(lambda: self.save_order('orders'))
        self.widget_add_ord.but_delete_order.clicked.connect(lambda: self.delete_column('structure_orders'))


        self.view_data(self.tableView, f'SELECT * FROM {self.table_name}')

    def view_data(self, tableview, sql_query):
        self.model1 = QSqlQueryModel()
        self.model1.setQuery(sql_query)
        tableview.setModel(self.model1)

    def view_order(self):
        self.view_data(self.widget_add_ord.tableView, f'SELECT * FROM structure_orders')
        self.sum = f'{self.datab.query_sum_orders()} Р'
        self.widget_add_ord.lb_sum_order_pr_3.setText(self.sum)

    def opr_id_cursor(self, tableview):
        index = tableview.selectedIndexes()[0]
        id = str(tableview.model().data(index))
        return id

    def add_new_column(self, list_in):
        id = self.datab.incr(self.table_name)
        self.opr_param(id, list_in)
        self.view_data(self.tableView, f'SELECT * FROM {self.table_name}')

    def opr_table(self, table_name):
        self.table_name = table_name
        self.view_data(self.tableView, f'SELECT * FROM {table_name}')

    def opr_param(self, id, data_input):
        if self.table_name == 'products' and (not self.data_input[4].text().isdigit() or not self.data_input[5].text().isdigit()):
            QMessageBox.information(self, 'Внимание', 'Неправильные данные! \nПоля Количество и Цена должны содержать числа!')
        else:
            self.param.append(id)
            for data in data_input:
                value = data.text() if not isinstance(data, QComboBox) else data.currentText()
                self.param.append(value)

            self.datab.query_add_new_column(self.table_name, self.param)
            self.view_data(self.tableView, f'SELECT * FROM {self.table_name}')

            self.param.clear()
            self.widget_add.close()

    def openWingetAdd(self, table_name):
        if table_name == 'workers':
            self.widget_add = widget_add_workers()
            self.widget_add.show()
            self.data_input = [self.widget_add.le_name, self.widget_add.le_surname,  self.widget_add.le_login, self.widget_add.le_password, self.widget_add.le_patronymic,
                               self.widget_add.date_birh, self.widget_add.le_phone, self.widget_add.combox_position]


        elif table_name == 'products':
            self.widget_add = widget_add_products()
            self.widget_add.show()
            self.data_input = [self.widget_add.le_name_products, self.widget_add.le_category_products, self.widget_add.le_brand_products, self.widget_add.le_description_products,
                               self.widget_add.le_quantity_products, self.widget_add.le_price_products]
        self.widget_add.but_save_add.clicked.connect(lambda: self.add_new_column(self.data_input))


    def search_column(self):
        id = self.le_name.text()
        sql_query = f'SELECT * FROM {self.table_name} WHERE ID={id}' if self.table_name != 'orders' else f'SELECT id, Дата, Сумма FROM {self.table_name} WHERE ID={id}'
        self.model1.setQuery(sql_query)
        self.tableView.setModel(self.model1)

    def delete_column(self, table_name):
        try:
            id = self.opr_id_cursor(self.tableView)
            if table_name == 'structure_orders':
                id = self.opr_id_cursor(self.widget_add_ord.tableView)
                self.datab.query_delete_column(table_name, id)
                del self.order[id]
                self.view_order()
            else:
                self.datab.query_delete_column(table_name, id)
                self.datab.update_id(table_name, id)
                self.view_data(self.tableView, f'SELECT * FROM {self.table_name}')

        except Exception as e:
            QMessageBox.information(self, 'Внимание', 'Выберите ID')

    def opr_products(self, index):
        if self.table_name == 'products' and self.widget_add_ord.isVisible() and index.column() == 0:
            id = self.opr_id_cursor(self.tableView)
            if self.datab.query_povtor(id):
                self.widget_kol = widget_add_kol_vo()
                self.widget_kol.show()
                self.widget_kol.but_confirm.clicked.connect(lambda: self.opr_kol_vo(id))
            else:
                QMessageBox.information(self, 'Внимание', 'Этот товар уже выбран!')

    def opr_kol_vo(self, id):
        kol_vo = self.widget_kol.le_kol.text()
        if kol_vo.isdigit() and int(kol_vo) > 0:
            if self.datab.query_add_product_of_orders(id, kol_vo):
                self.order[id] = kol_vo
                self.widget_kol.close()
                self.view_order()
            else:
                QMessageBox.information(self, 'Внимание', 'Запрашиваемое количество товара больше доступного на складе! ')
        else:
            self.widget_kol.le_kol.setText('')
            self.widget_kol.le_kol.setPlaceholderText('Неправильные данные!')


    def cancel_order(self):
        self.widget_add_ord.close()
        self.order.clear()
        self.datab.query_delete_data('structure_orders')
        self.view_data(self.tableView, f'SELECT * FROM {self.table_name}')

    def save_order(self, table_name):
        self.datab.update_product_quantit(self.order)
        self.cancel_order()

    def print_structure_order_in_word(self):
        try:
            time = QDateTime.currentDateTime().toString('dd.MM.yy hh:mm:ss')

            self.datab.execute_query_with_params('SELECT * FROM structure_orders')
            data = self.datab.cursor.fetchall()

            doc = Document()
            doc.add_heading(f'Накладная {time}\n', level=1).paragraph_format.alignment = 1

            columns = [description[0] for description in self.datab.cursor.description]
            table = doc.add_table(rows=1, cols=len(columns))
            table.style = 'TableGrid'

            for col_num, column in enumerate(columns):
                table.cell(0, col_num).text = column

            for row in data:
                row_cells = table.add_row().cells
                for col_num, value in enumerate(row):
                    row_cells[col_num].text = str(value)

            total_amount_paragraph = doc.add_paragraph()
            total_amount_run = total_amount_paragraph.add_run(f'Общая сумма:')
            total_amount_paragraph.add_run(f' {self.sum}\n').bold = True
            total_amount_paragraph.alignment = 2

            buyer = doc.add_paragraph()
            buyer = buyer.add_run('Покупатель: __________________  ________')
            buyer.alignment = 0

            seller = doc.add_paragraph()
            seller = seller.add_run('Продавец: _____________________  ________')
            seller.alignment = 0

            doc.save('output.docx')
            self.widget_add_ord.message_word()
        except Exception as e:
            print(f"Ошибка при выполнении запроса: {e}")


    def show_about_info(self):
        QMessageBox.information(self, 'Информация о программе',
                            'Название: Программа для анализа и учёта заказов\n'
                            'Автор: Лепихов Михаил Владимирович\n'
                            'Год создания: 2023')

    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Подтверждение', 'Вы уверены, что хотите закрыть приложение?', QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            event.accept()
            self.widget_kol.close()
            self.widget_add.close()
            self.cancel_order()

        else:
            event.ignore()

    def close_all_windows(self):
        QApplication.closeAllWindows()

    def openWingetAnalyze(self):
        self.widget_analyze = widget_add_analyze()
        self.widget_analyze.show()

    def openWingetAddOrder(self):
        self.widget_add_ord.but_save_order.setVisible(True)
        self.widget_add_ord.but_delete_order.setVisible(True)

        self.opr_table('products')
        self.view_data(self.tableView, f'SELECT * FROM products')
        self.table_name = 'products'
        self.widget_add_ord.show()
        self.view_order()



class widget_add_workers(QDialog, Ui_Dialog_employee):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setModal(True)

class widget_add_products(QDialog, Ui_Dialog_products):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setModal(True)

class widget_add_analyze(QDialog, Ui_Dialog_analyze):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setModal(True)

class widget_add_order(QWidget, Ui_Form_order):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.tableView.verticalHeader().setVisible(False)

    def message_word(self):
        QMessageBox.information(self, 'Внимание', 'Успешно! ')

class widget_add_kol_vo(QDialog, Ui_Dialog_kol_vo):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setModal(True)


if __name__ == '__main__':
    app = QApplication([])
    win1 = LoginForm()
    win1.show()
    sys.exit(app.exec())